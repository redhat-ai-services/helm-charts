# llm-d-kserve

A Helm chart for deploying LLM-D with KServe on OpenShift AI

![Version: 0.2.0](https://img.shields.io/badge/Version-0.2.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 3.3.0](https://img.shields.io/badge/AppVersion-3.3.0-informational?style=flat-square)

## Installing the Chart

To access charts from this from the cli repository add it:

```sh
helm repo add redhat-ai-services https://redhat-ai-services.github.io/helm-charts/
helm repo update redhat-ai-services
helm upgrade -i [release-name] redhat-ai-services/llm-d-kserve
```

To include a chart from this repository in an umbrella chart, include it in your dependencies in your `Chart.yaml` file.

```yaml
apiVersion: v2
name: example-chart
description: A Helm chart for Kubernetes
type: application

version: 0.1.0

appVersion: "1.16.0"

dependencies:
  - name: "llm-d-kserve"
    version: "0.2.0"
    repository: "https://redhat-ai-services.github.io/helm-charts/"
```

## Usage

### Quick Start

TODO

## Configuration

For a complete list of all configuration options, see the [Values](#values) section below.

## Source Code

* <https://github.com/redhat-ai-services/helm-charts/tree/main/charts/llm-d-kserve>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| auth.enabled | bool | `true` | Secures the model endpoint and creates a role to grant permissions to service accounts |
| auth.serviceAccounts | list | `[{"name":"my-service-account"},{"create":false,"name":"existing-service-account"},{"create":false,"name":"existing-in-another-namespace","namespace":"my-other-namespace"},{"createLegacyToken":false,"name":"no-token"}]` | Creates service accounts with permissions to access the secured endpoint If create not set, assume true; if create is set to false, the service account must already exist. If createLegacyToken is unset or true, a static legacy token secret is created for that entry; set createLegacyToken: false to opt out. If namespace not set, assume the release namespace. |
| dataConnection.create | bool | `true` | Creates a data connection and adds it to the release namespace. |
| dataConnection.name | string | `""` | The name of the data connection to use.  If not set, the data connection will be created with the release name. |
| fullnameOverride | string | `""` | String to fully override fullname template |
| hardwareProfile.create | bool | `false` | Creates a hardware profile and adds it to the release namespace. |
| hardwareProfile.identifiers | list | `[]` | The identifiers to add to the hardware profile. This value will only be used if create is set to true. |
| hardwareProfile.name | string | `"nvidia-gpu"` | The name of the hardware profile to use. If create is set to true, this value will be ignored and the hardware profile will be created with the release name. |
| hardwareProfile.namespace | string | `"redhat-ods-applications"` | The namespace of the hardware profile to use. If create is set to true, this value will be ignored and the hardware profile will be created in the release namespace. |
| hardwareProfile.tolerations | list | `[]` | The tolerations to apply to the hardware profile. This value will only be used if create is set to true. |
| imagePullSecrets | list | `[]` | The image pull secrets to use for the model server. |
| model.name | string | `"meta-llama/llama-3.2-1b-instruct"` | The name of the model to be advertised  in the /v1/models endpoint |
| model.uri | string | `"oci://quay.io/redhat-ai-services/modelcar-catalog:llama-3.2-1b-instruct"` | The URI of the model to be used by the model server |
| nameOverride | string | `""` | String to partially override fullname template (will maintain the release name) |
| scheduler.endpointPickerConfig | string | `""` |  |
| vllm.additionalArguments | list | `[]` | The additional arguments to pass to the model server. |
| vllm.image.pullPolicy | string | `"IfNotPresent"` | The pull policy of the image to use for the model server |
| vllm.image.repository | string | `""` | The repository of the image to use for the model server If not set, the default image will be used. |
| vllm.image.tag | string | `""` | The tag of the image to use for the model server |
| vllm.replicaCount | int | `1` | The number of replicas to run for the model server |
| vllm.resources | object | `{}` | The resources to apply to the model server pod. If not set, the hardware profile will add the default resources, however it is highly recommended to set the resources explicitly. |
| vllm.tolerations | list | `[]` | The tolerations to apply to the model server pod. If not set, the hardware profile will add the default tolerations. |
| vllm.topologySpreadConstraints | list | `[{"maxSkew":1,"topologyKey":"kubernetes.io/hostname","whenUnsatisfiable":"ScheduleAnyway"}]` | Pod topology spread constraints for the model server. If labelSelector is omitted on an item, the chart sets matchLabels app.kubernetes.io/name to llm-d-kserve.fullname. |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
